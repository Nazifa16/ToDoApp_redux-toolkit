import todoSlice from "./todoSlice";


export const reducers = {
    todo: todoSlice
} 